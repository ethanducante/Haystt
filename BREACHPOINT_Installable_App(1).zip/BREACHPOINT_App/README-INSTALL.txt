# BREACHPOINT — Installable Web App

This package turns the supplied BREACHPOINT Prototype 002 into an installable PWA.

## Publish it
1. Extract this ZIP.
2. Upload **all files and folders** to the root of a GitHub repository (keep `index.html`, `manifest.webmanifest`, `sw.js`, and `icons/` together).
3. In GitHub, open **Settings → Pages**.
4. Set deployment to **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. Wait for the Pages URL to appear.

## Install on Android
1. Open the published HTTPS URL in Chrome.
2. Open the ⋮ menu and choose **Install app** or **Add to Home screen**.
3. Confirm. BREACHPOINT will appear on your home screen and open in its own app-style window.

## Install on iPhone/iPad
1. Open the HTTPS URL in Safari.
2. Tap Share → **Add to Home Screen**.

## PC
Open the HTTPS URL in Chrome or Edge and use the install icon in the address bar (or browser menu → Install).

## Important limitations
- This is an installable web app, not a compiled native Android APK or iOS App Store app.
- The game imports Three.js from jsDelivr, so internet is required on the first load and may be needed again if that CDN resource is not cached.
- This prototype currently uses local AI bots. It does not include online 5v5 multiplayer, accounts, matchmaking, or ranked servers.
- For the most reliable install experience, host it on HTTPS (GitHub Pages is free).
